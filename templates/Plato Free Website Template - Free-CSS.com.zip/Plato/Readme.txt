Thanks for downloading this theme!

Theme Name: Plato
Theme URL: https://bootstrapmade.com/plato-responsive-bootstrap-website-template/
Author: BootstrapMade.com
Author URL: https://bootstrapmade.com
